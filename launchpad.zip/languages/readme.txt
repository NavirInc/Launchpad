# How to generate a POT file

Navigate to your theme or plugin and execute the following command (after [WP-CLI](https://make.wordpress.org/cli/handbook/guides/installing/) is installed):

```$ wp i18n make-pot . languages/my-plugin.pot```