<?php
/**
 * The template for the home page pages.
 * 
 * @package launchpad
 * @since launchpad 0.0.0
 */
get_header(); ?>

    <main id="primary" class="site-main">

        <!-- CONTENT HERE -->

    </main>

<?php get_footer(); ?>