<?php
/**
 * The template for displaying 404 (Not Found) errors. This file is displayed
 * when a requested page is not found on the server. It often includes a
 * search form or links to help users navigate the site and provides a
 * user-friendly message indicating the page is not available.
 * 
 * @package launchpad
 * @since launchpad 0.0.0
 */
get_header(); ?>


<!-- CONTENT HERE -->


<?php get_footer(); ?>