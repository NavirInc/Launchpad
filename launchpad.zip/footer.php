<?php
/**
 * The template for displaying the footer. This file includes the closing tag
 * for the main content section and contains footer content such as copyright
 * information, site credits, and any additional footer widgets or menus. 
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * 
 * @package launchpad
 * @since launchpad 0.0.0
 */
?>

    <footer>
        <!-- CONTENT HERE -->
    </footer>

<?php wp_footer();?>
</body>
</html>