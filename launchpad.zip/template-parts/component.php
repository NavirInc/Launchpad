<?php
/**
 * This file is an exemple of template parts used in various page. Replace "component" than delete this line.
 *
 * To use this template on a page, add this code:
 * <?php get_template_part('template-parts/component', null, ["var1"=>"value1", "var2"=>"value2"]); ?>
 *
 * To access argument, use the variables $var1 and $var2, etc.
 */
?>

<!-- CONTENT HERE -->